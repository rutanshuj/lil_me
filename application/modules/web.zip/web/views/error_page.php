<div class="container" >
	<section>
	<div class="col-sm-12 cont_top" align='center' style="margin-top: 2%; margin-bottom: 4%;">
	<img src="<?php echo base_url();?>assets/svgs/404.svg" class="img-responsive image" >
	<h3 align="center">
				We cant seem to find a page<br>
				you're looking for
			</h3>
	<a href="<?php echo base_url('web/home');?>" class="btn btn-info">Back To Home</a>
	</div>
	</section>
</div>