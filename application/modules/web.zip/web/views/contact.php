					
					<div class="container" style="padding-left: 8%;padding-right: 8%;padding-top: 2%;">
					<div class="row">
                            <div class="col-sm-6">
							<div class="address">
                               <img src="<?php echo base_url();?>assets/svgs/ic_location_on_black_24px.svg" 
							   style="height: 70px;margin-left: 42%;">
                                <p align="center">130, Pandurang Budhkar Marg, BDD Chawls, Worli,
                                 <br>   Mumbai,
								<br>Maharashtra - 400018
                                    
                                </p>
								</div>
                            </div>
                            <!-- /.col-sm-4 -->
                            <div class="col-sm-6 ">
							<div id='map' style="margin-top: 6%;">
                              <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3772.3141909895953!2d72.81799631490007!3d19.005871987128206!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7ce96c6993105%3A0xac45fc4c5262e84f!2s130%2C+Pandurang+Budhkar+Marg%2C+BDD+Chawls+Worli%2C+Worli%2C+Mumbai%2C+Maharashtra+400018!5e0!3m2!1sen!2sin!4v1479199635602" style="border:0;border: 1px solid black;width: 100%;"  height="250" frameborder="0" style="border:0" allowfullscreen></iframe> 
                            </div>
                          </div>
						  <div class="col-sm-12">
						  <div class='contact'style="margin-bottom: 6%;">
						   <p align="center"> <img src="<?php echo base_url();?>assets/svgs/ic_call_black_24px.svg" style="height: 55px;"></p>
						  <p align="center">
						  022 3967 7000 / 022 3967 8888 / 022 3967 9999
						  </p>
						  <p align="center"><img src="<?php echo base_url();?>assets/svgs/ic_email_black_24px.svg" style="height: 55px;" ></p>
						  <p align="center">
						<a href="mailto:"> mail@lilme.com</a>
						  </p>
						  </div>
						  </div>
						  </div>
                        </div>
						
    