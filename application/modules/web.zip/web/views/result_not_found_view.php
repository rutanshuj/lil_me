<div class="container" >
	<section>
	<div class="col-sm-12 cont_top" align='center' style="margin-top: 2%; margin-bottom: 4%;">
	<img src="<?php echo base_url();?>assets/svgs/not_found.svg" class="img-responsive image" >
	<h3 align="center">
				No Results Found
			</h3>
	<a href="<?php echo base_url('products/'.$category_slug.'/');?>" class="btn btn-info">Back To Gallery</a>
	</div>
	</section>
</div>