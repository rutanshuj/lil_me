<div class="container" style="min-height: 570px;">
<div class="row">
<div class="col-sm-12" >
			<p class="text-muted lead" align="center" style="font-size: 33px;">
				About Us
			</p>
		
	</div>
	<div class="col-sm-12 cont_top" style="font-size: 20px;">
	

                        
                        <p>As we know all good stories beginwith ‘Once Upon a Time’. July 2015 to be exact – in Mumbai where our founder Akshay Suri, a fabric exporter a childrenswear buyer and a father himself spotted a gap in the market for affordable, basic, and quality kidswear. And as they say, parents know best!
Designed for simplicity and comfort, our clothes are made from soft, natural fabrics with smooth seams and no scratchy, itchy bits.</p><p>
</p><p>There’s just something about Li’l Me that will make you smile. Whether it’s because we choose quality and practically natural fabrics that last or because we add gorgeousness to simplicity.
</p><p>Whatever it is, we love it!!! 
And you will too!!!</p><p>
Let those ‘Li’l Ones’loose, our clothes are meant for it!  


</p>

                    
					</div>
						
                        </div>
</div>