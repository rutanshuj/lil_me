<div class="container" >
	<section>
	<div class="col-sm-12 cont_top" align='center' style="margin-top: 2%; margin-bottom: 2%;">
	<img src="<?php echo base_url();?>assets/svgs/thankyou.svg" class="img-responsive image" >
	
	<a href="<?php echo base_url('web/payment/order_history');?>" class="btn btn-info">view Order History</a>
	</div>
	</section>
</div>